library(shiny)
library(shinyalert)

shinyUI(fluidPage(

  tags$style(HTML(".js-irs-0 .irs-single, .js-irs-0 .irs-bar-edge,
                  .js-irs-0 .irs-bar {background: BLACK}")),
  tags$style(HTML(".js-irs-1 .irs-single, .js-irs-1 .irs-bar-edge,
                  .js-irs-1 .irs-bar {background: BLACK}")),

    #____Couleurs de l'arrière plan et des boutons cliquable
  tags$head(
    tags$style(HTML("
  body {background-color:#FF9933;}
                 #reset{color: white;
                 background-color: GREEN;}

                 #drap{color:green; background-color:   }
                  #go{color:red;background-color:white;}
                ")
    )
  ),

  #Titre du jeu
  h1("Démineur 💣"),

  sidebarLayout(

    sidebarPanel(

      sliderInput("ligne", "Nombre de lignes :", 5, min = 4, max = 30),

      hr(),

      sliderInput("colonne", "Nombre de colonnes :", 5, min = 4, max = 30),
#__________Bouton pour jouer
      actionButton("reset", "Nouvelle partie"),

      hr(),

      numericInput("case", "Sélectionne une case :", 1, min = 1, max = 900),
#_________________Bouton pour creuser
      actionButton("go", "Creuser", icon = icon("trowel")),
#___________________Drapeau
      actionButton("drap", "🚩"),

    ),

    mainPanel(
      textOutput("bombe"),
      hr(),
      tableOutput("board")
    )
  )
))
